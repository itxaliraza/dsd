package com.practice.coroutines.gallery

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.practice.coroutines.databinding.ActivityGalleryBinding
import com.google.android.material.tabs.TabLayoutMediator
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class GalleryActivity : AppCompatActivity() {
    @Inject
    lateinit var binding: ActivityGalleryBinding

    val tabsArray = arrayOf(
        "Photo",
        "Video",
    )
    val adapter = GalleryPagerAdapter(supportFragmentManager, lifecycle)


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)


        with(binding) {
            binding.galleryViewPager.adapter = adapter

            TabLayoutMediator(tabLayout, binding.galleryViewPager) { tab, position ->
                tab.text = tabsArray[position]
            }.attach()
        }
    }
}