package com.practice.coroutines.quotes.multiple_quote

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.practice.coroutines.quotes.data.repo.MultipleQuotesRepositoryImpl
import com.practice.coroutines.quotes.domain.repo.MultipleQuotesrepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class PopularQuotesViewModel @Inject constructor(private val quotesrepository: MultipleQuotesRepositoryImpl) :
    ViewModel() {
    fun fetchQuoteOfDay() {
        viewModelScope.launch {
            quotesrepository.getQuotesList()
        }
    }

    init {
        viewModelScope.launch {
            fetchQuoteOfDay()
        }
    }

    val quoteOfDay =
        quotesrepository.quotesList.stateIn(viewModelScope, SharingStarted.Eagerly, null)

}