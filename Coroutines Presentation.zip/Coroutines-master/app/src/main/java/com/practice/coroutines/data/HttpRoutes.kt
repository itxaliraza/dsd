package com.practice.coroutines.data

object HttpRoutes {
    const val BASE_URL = "https://zenquotes.io/api/"

}