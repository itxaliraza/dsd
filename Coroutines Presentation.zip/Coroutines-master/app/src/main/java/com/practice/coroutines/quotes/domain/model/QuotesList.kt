package com.practice.coroutines.quotes.domain.model

class QuotesList : ArrayList<QuoteItem>()