package com.practice.coroutines.gallery

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.practice.coroutines.domain.model.MyResult
import com.practice.coroutines.gallery.data.PhotosPicker
import com.practice.coroutines.gallery.data.VideosPicker
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class GalleryViewmodel @Inject constructor(
    private val photosPicker: PhotosPicker,
    private val videosPicker: VideosPicker
) : ViewModel() {

    val photosState = photosPicker.photosPickerStateFlow.stateIn(
        viewModelScope,
        SharingStarted.Eagerly,
        MyResult.Idle
    )

    val videosState = videosPicker.videosPickerStateFlow.stateIn(
        viewModelScope,
        SharingStarted.Eagerly,
        MyResult.Idle
    )


    init {

        //bad practice
        viewModelScope.launch {
            photosPicker.queryMedia()
            videosPicker.queryVideos()
        }

        //good one
        viewModelScope.launch {

            launch {
                photosPicker.queryMedia()
            }
            launch {
                videosPicker.queryVideos()
            }
        }

}
}