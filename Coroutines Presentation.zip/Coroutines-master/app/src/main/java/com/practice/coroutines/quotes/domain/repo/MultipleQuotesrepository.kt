package com.practice.coroutines.quotes.domain.repo

import com.practice.coroutines.domain.model.MyResult
import com.practice.coroutines.quotes.domain.model.QuotesList
import kotlinx.coroutines.flow.StateFlow

interface MultipleQuotesrepository {
    suspend fun getQuotesList()
    val quotesList: StateFlow<MyResult<QuotesList>>
}