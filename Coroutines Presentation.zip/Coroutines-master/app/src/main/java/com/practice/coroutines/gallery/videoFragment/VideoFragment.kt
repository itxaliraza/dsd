package com.practice.coroutines.gallery.videoFragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import com.practice.coroutines.databinding.FragmentMediaBinding
import com.practice.coroutines.domain.model.MyResult
import com.practice.coroutines.gallery.GalleryViewmodel
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import javax.inject.Inject

@AndroidEntryPoint
class VideoFragment : Fragment() {
    val galleryViewmodel: GalleryViewmodel by activityViewModels()

    @Inject
    lateinit var videoAdapter: VideoAdapter

    @Inject
    lateinit var binding: FragmentMediaBinding
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        with(binding) {
            rvMedia.apply {
                layoutManager = GridLayoutManager(context, 2)
                adapter = videoAdapter
            }

            lifecycleScope.launch {
                galleryViewmodel.videosState.collectLatest {
                    when (it) {
                        is MyResult.Failure -> {

                        }

                        MyResult.Idle -> {
                            pbMain.visibility = View.VISIBLE
                        }

                        MyResult.Loading -> {
                            pbMain.visibility = View.VISIBLE
                        }

                        is MyResult.Success -> {
                            pbMain.visibility = View.GONE
                            videoAdapter.submitList(it.data)
                        }
                    }
                }
            }
        }

    }

}