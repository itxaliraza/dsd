package com.practice.coroutines.quotes.domain.repo

import com.practice.coroutines.domain.model.MyResult
import com.practice.coroutines.quotes.domain.model.QuoteItem
import kotlinx.coroutines.flow.StateFlow

interface SingleQuotesrepository {
    suspend fun fetchQuoteOfDayIfNotFetched()
    val quoteOfDay: StateFlow<MyResult<QuoteItem>>
}