package com.practice.coroutines.quotes.data.repo

import com.practice.coroutines.domain.model.MyResult
import com.practice.coroutines.quotes.data.api.QuotesApi
import com.practice.coroutines.quotes.domain.model.QuotesList
import com.practice.coroutines.quotes.domain.repo.MultipleQuotesrepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject

class MultipleQuotesRepositoryImpl @Inject constructor(private val quotesApi: QuotesApi) :
    MultipleQuotesrepository {


    private val _quotesListFlow: MutableStateFlow<MyResult<QuotesList>> =
        MutableStateFlow(MyResult.Idle)


    override val quotesList: StateFlow<MyResult<QuotesList>>
        get() = _quotesListFlow.asStateFlow()


    override suspend fun getQuotesList() {
        try {
            _quotesListFlow.value = MyResult.Loading

            val response = quotesApi.getQuotesList()
            _quotesListFlow.value = if (response?.isSuccessful == true) {
                response.body()?.let {
                    MyResult.Success(it)
                } ?: MyResult.Failure("Unknown Error")
            } else {
                MyResult.Failure(response?.message() ?: "Unknown Error")
            }
        } catch (e: Exception) {
            _quotesListFlow.value = MyResult.Failure(e.message ?: "Unknown Error")
        }
    }
}

