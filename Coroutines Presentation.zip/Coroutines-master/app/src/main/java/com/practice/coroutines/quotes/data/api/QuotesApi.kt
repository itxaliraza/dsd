package com.practice.coroutines.quotes.data.api

import com.practice.coroutines.quotes.domain.model.QuotesList
import retrofit2.Response
import retrofit2.http.GET

interface QuotesApi {

    @GET("today")
    suspend fun getQuoteOfTheDay(): Response<QuotesList>?

    @GET("quotes")
    suspend fun getQuotesList(): Response<QuotesList>?

}